package cn.dazd.oa.sync.repo;

public interface IBaseRepo {
}
