package cn.dazd.oa.sync.entity;

public class BaseEntity {
}
