package cn.dazd.oa.sync.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@EqualsAndHashCode
@Data
@ToString
public class EcoMatrixVO {
    private String matrixName;
    private int matrixInfoId;
}
