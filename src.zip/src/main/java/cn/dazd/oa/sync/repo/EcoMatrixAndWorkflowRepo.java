package cn.dazd.oa.sync.repo;

import cn.dazd.oa.sync.entity.EcoMatrixAndWorkflowEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EcoMatrixAndWorkflowRepo extends JpaRepository<EcoMatrixAndWorkflowEntity, Integer> {
}
